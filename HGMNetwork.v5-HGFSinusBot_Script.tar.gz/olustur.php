<?php
if (isset($_POST['g-recaptcha-response'])) {
    $HGMNet_captcha = $_POST['g-recaptcha-response'];
}
if (!$HGMNet_captcha) {
    exit('<p><hr><font color=red><font size=5><b>reCAPTCHA Bilgileri Hatali, Lutfen Tekrar Deneyin..!</font></p><hr></b>');
}
$HGMNet_Robot_Kontrol = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret='.$HGMNetwork_reCAPTCHA_GizliKey.'&response=" . $HGMNet_captcha . "&remoteip=" . $_SERVER['REMOTE_ADDR']);
if ($HGMNet_Robot_Kontrol.success == false) {
    exit('<p><hr><font color=red><font size=5><b>reCAPTCHA Bilgileri Hatali, Lutfen Tekrar Deneyin..!</font></p><hr></b>');
}

set_include_path("HGMNetwork_FreeSinus/");
include('Net/SSH2.php');

$ip = $_SERVER['REMOTE_ADDR'];
$HGMNetwork_SinusBot_RandomPort = substr(str_shuffle("123456789"), 0, 4);
$HGMNetwork_Random_Sifre = substr(str_shuffle("1234567890qwertQWERTasdfgASDFGzxcvbZXCVB"), 0, 11);
sleep(1);

//====================================================
// #HGMNetwork.v5 Script Ucretiz SinusBot Paneli
// #Coded: HGMNetwork By HGM
//====================================================
//////////////////////////////////////////////////////
//====================================================
// [HGMNetwork] #Bu Bolumde Sunucu Bilgileri Bulunur;
//====================================================
//====================================================
//====================================================
$HGMNetwork_Anadizin = "/home/sinusbot/"; // Gerekmedikce Ellemeyin..!
//====================================================
//////////////////////////////////////////////////////

$ssh = new Net_SSH2(''.$HGMNetwork_SinusBot_MakineIp.'');
if (!$ssh->login(''.$HGMNetwork_ServerKullaniciAdi.'', ''.$HGMNetwork_Server_Parolasi.''))
{
    exit('<p><hr><font color=red><font size=5><b>Sunucu Bilgileri Hatali, Lutfen Tekrar Deneyin..!</font></p><hr></b>');
}else{
$ssh->exec('cd '.$HGMNetwork_Anadizin.' && sudo ./HGMNetwork_SinusFiles -HG_72398741474374888312751537525672884677211938419264');
$ssh->exec('mkdir -p /opt/ts3soundboard'.$HGMNetwork_SinusBot_RandomPort.'/');
$ssh->exec('cp -r /opt/HGMNet_SinusbotFiles/* /opt/ts3soundboard'.$HGMNetwork_SinusBot_RandomPort.'/');
$ssh->exec('echo ListenPort = '.$HGMNetwork_SinusBot_RandomPort.' > /opt/ts3soundboard'.$HGMNetwork_SinusBot_RandomPort.'/config.ini');
$ssh->exec('cd '.$HGMNetwork_Anadizin.' && cp -r HGMNetwork_PhpSinusbot_Konfig /opt/ts3soundboard'.$HGMNetwork_SinusBot_RandomPort.'/');
$ssh->exec('cd /opt/ts3soundboard'.$HGMNetwork_SinusBot_RandomPort.'/ && sudo ./HGMNetwork_PhpSinusbot_Konfig -HG_81708707680279505562402924922760480313176009544127');
$ssh->exec('cd /opt/ts3soundboard'.$HGMNetwork_SinusBot_RandomPort.'/ && rm -rf HGMNetwork_PhpSinusbot_Konfig');
$ssh->exec('rm -rf /opt/TeamSpeak3-Client-linux_amd64/xcbglintegrations/libqxcb-glx-integration.so');
$ssh->exec('chmod 777 /opt/ts3soundboard'.$HGMNetwork_SinusBot_RandomPort.'/*');
$ssh->exec('cd /opt/ts3soundboard'.$HGMNetwork_SinusBot_RandomPort.'/ && mkdir -p dataciklariniz/');
$ssh->exec('cd /opt/ts3soundboard'.$HGMNetwork_SinusBot_RandomPort.'/ && chown -R sinusbot:sinusbot dataciklariniz/');
$ssh->exec('chown -R sinusbot:sinusbot /opt/ts3soundboard'.$HGMNetwork_SinusBot_RandomPort.'/');
$ssh->exec('chmod 777 /opt/ts3soundboard'.$HGMNetwork_SinusBot_RandomPort.'/*');
$ssh->exec('rm -rf /tmp/.sinusbot.lock');
$ssh->exec('rm -rf /tmp/.X11-unix/X40');

$ssh->exec('cd /opt/ts3soundboard'.$HGMNetwork_SinusBot_RandomPort.'/ && su sinusbot -c "screen -A -m -d -S sinusbot'.$HGMNetwork_SinusBot_RandomPort.' ./sinusbot --override-password='.$HGMNetwork_Random_Sifre.'"');
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
	<meta name="author" content="">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<title>HGMNetwork - Ucretsiz SinusBot Paneli</title>
</head>
<!-- HGMNetwork_Free_SinusBot_Script, Coded By HGMNetwork -->
<style type="text/css">
<!--

body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
        background-image: url('HGMNetwork_FreeSinus/HGMNetwork_Background.jpg');
        background-repeat: no-repeat;
}

.HGMNetwork_Rengarenk span{
    font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
    font-weight: bold;
    font-size: 70px;
    text-shadow: 1px 1px 0px #A3A3A3;
    display: inline-block;
}

.HGMNetwork_Rengarenk_font45 span{
    font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
    font-weight: bold;
    font-size: 45px;
    text-shadow: 1px 1px 0px #A3A3A3;
    display: inline-block;
}

.HGMNetwork_Buton{
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.HGMNet_Buton{
  display: block;
  width: 200px;
  height: 40px;
  line-height: 40px;
  font-size: 18px;
  font-family: sans-serif;
  text-decoration: none;
  color: #333;
  border: 2px solid #333;
  letter-spacing: 2px;
  text-align: center;
  position: relative;
  transition: all .35s;
}

.HGMNet_Buton span{
  position: relative;
  z-index: 2;
}

.HGMNet_Buton:after{
  position: absolute;
  content: "";
  top: 0;
  left: 0;
  width: 0;
  height: 100%;
  background: #ff003b;
  transition: all .35s;
}

.HGMNet_Buton:hover{
  color: #fff;
}

.HGMNet_Buton:hover:after{
  width: 100%;
}
</style>
<body>
<center><br><br>

<div class="HGMNetwork_Rengarenk">
<span style="color:#ff0000">H</span><span style="color:#ff1100">G</span><span style="color:#ff2200">M</span><span style="color:#ff3300">N</span><span style="color:#ff4400">e</span><span style="color:#ff5500">t</span><span style="color:#ff6600">w</span><span style="color:#ff7700">o</span><span style="color:#ff8800">r</span><span style="color:#ff9900">k</span>
</div>
<br>
<div class="HGMNetwork_Rengarenk_font45">
<span style="color:#ff00ff">U</span><span style="color:#ff00cc">c</span><span style="color:#ff0099">r</span><span style="color:#ff0066">e</span><span style="color:#ff0033">t</span><span style="color:#ff0000">s</span><span style="color:#ff3300">i</span><span style="color:#ff6600">z</span> <span style="color:#66ff00"></span> <span style="color:#ff9900">S</span><span style="color:#ffcc00">i</span><span style="color:#ffff00">n</span><span style="color:#ccff00">u</span><span style="color:#99ff00">s</span><span style="color:#66ff00">b</span><span style="color:#33ff00">o</span><span style="color:#00ff00">t</span> <span style="color:#66ff00"></span> <span style="color:#00ff33">O</span><span style="color:#00ff66">l</span><span style="color:#00ff99">u</span><span style="color:#00ffcc">s</span><span style="color:#00ffff">t</span><span style="color:#00ccff">u</span><span style="color:#0099ff">r</span><span style="color:#0066ff">m</span><span style="color:#0033ff">a</span>
</div>
<br><br>

<?php
echo "<font color='green'><font size=3><strong>SinusBot Basariyla Olusturuldu..!</strong><br>Giris-Bilgileri; <br><br>Panel URL: <font color=red> http://".$HGMNetwork_SinusBot_MakineIp.":".$HGMNetwork_SinusBot_RandomPort."<br><font color='green'>Kullanici adi:<font color=red> admin<br><font color='green'>Sifre:<font color=red> ".$HGMNetwork_Random_Sifre."";
?>

<br><br>
<div class="HGMNet_Buton">
<a href="index.php"><font color=black><span>Geri Donme</span></a>
</div>

<br><br>
<font size=4><b>Kullandiginiz Ip:</b> <font color="red"> <font size=2> <b>[<?php echo $ip; ?>]</b></font><font color=#FFFFFF><font size=2> &nbsp;<b>(Guvenlik Kosullari Nedeniyle<font color =red> Kayit Altindadir..!</font>)</font><br><br>
