<?php
$ip = $_SERVER['REMOTE_ADDR'];

//====================================================
// #HGMNetwork.v5 Script Ucretiz SinusBot Paneli
// #Coded: HGMNetwork By HGM
//====================================================
//////////////////////////////////////////////////////
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
	<meta name="HGMNetwork By HGM" content="Ucretsiz Sinusbot Sistemi">
	<script src='https://www.google.com/recaptcha/api.js?hl=tr'></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<title>HGMNetwork - Ucretsiz Sinusbot Paneli</title>
</head>
<!-- HGMNetwork_Free_SinusBot_Script, Coded By HGMNetwork -->
<style type="text/css">
<!--

body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
        background-image: url('HGMNetwork_FreeSinus/HGMNetwork_Background.jpg');
        background-repeat: no-repeat;
}

.HGMNetwork_Rengarenk span{
    font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
    font-weight: bold;
    font-size: 70px;
    text-shadow: 1px 1px 0px #A3A3A3;
    display: inline-block;
}

.HGMNetwork_Rengarenk_font45 span{
    font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
    font-weight: bold;
    font-size: 45px;
    text-shadow: 1px 1px 0px #A3A3A3;
    display: inline-block;
}

.HGMNetwork_Rengarenk_font30 span{
    font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
    font-weight: bold;
    font-size: 30px;
    text-shadow: 1px 1px 0px #A3A3A3;
    display: inline-block;
}

.HGMNetwork_Buton {
    width: 220px;
    height: 50px;
    border: none;
    outline: none;
    color: #fff;
    background: #111;
    cursor: pointer;
    position: relative;
    z-index: 0;
    border-radius: 10px;
}

.HGMNetwork_Buton:before {
    content: '';
    background: linear-gradient(45deg, #ff0000, #ff7300, #fffb00, #48ff00, #00ffd5, #002bff, #7a00ff, #ff00c8, #ff0000);
    position: absolute;
    top: -2px;
    left:-2px;
    background-size: 400%;
    z-index: -1;
    filter: blur(5px);
    width: calc(100% + 4px);
    height: calc(100% + 4px);
    animation: glowing 20s linear infinite;
    opacity: 0;
    transition: opacity .3s ease-in-out;
    border-radius: 10px;
}

.HGMNetwork_Buton:active {
    color: #000
}

.HGMNetwork_Buton:active:after {
    background: transparent;
}

.HGMNetwork_Buton:hover:before {
    opacity: 1;
}

.HGMNetwork_Buton:after {
    z-index: -1;
    content: '';
    position: absolute;
    width: 100%;
    height: 100%;
    background: #111;
    left: 0;
    top: 0;
    border-radius: 10px;
}

@keyframes glowing {
    0% { background-position: 0 0; }
    50% { background-position: 400% 0; }
    100% { background-position: 0 0; }
}

-->
</style>
<!-- HGMNetwork_Free_SinusBot_Script, Coded By HGMNetwork -->
<body>
<center><br><br>
<form id="HGMNetwork_Gonder" action="olustur.php" method="post">
<div class="HGMNetwork_Rengarenk">
<span style="color:#ff0000">H</span><span style="color:#ff1100">G</span><span style="color:#ff2200">M</span><span style="color:#ff3300">N</span><span style="color:#ff4400">e</span><span style="color:#ff5500">t</span><span style="color:#ff6600">w</span><span style="color:#ff7700">o</span><span style="color:#ff8800">r</span><span style="color:#ff9900">k</span>
</div>
<br>
<div class="HGMNetwork_Rengarenk_font45">
<span style="color:#ff00ff">U</span><span style="color:#ff00cc">c</span><span style="color:#ff0099">r</span><span style="color:#ff0066">e</span><span style="color:#ff0033">t</span><span style="color:#ff0000">s</span><span style="color:#ff3300">i</span><span style="color:#ff6600">z</span> <span style="color:#66ff00"></span> <span style="color:#ff9900">S</span><span style="color:#ffcc00">i</span><span style="color:#ffff00">n</span><span style="color:#ccff00">u</span><span style="color:#99ff00">s</span><span style="color:#66ff00">b</span><span style="color:#33ff00">o</span><span style="color:#00ff00">t</span> <span style="color:#66ff00"></span> <span style="color:#00ff33">O</span><span style="color:#00ff66">l</span><span style="color:#00ff99">u</span><span style="color:#00ffcc">s</span><span style="color:#00ffff">t</span><span style="color:#00ccff">u</span><span style="color:#0099ff">r</span><span style="color:#0066ff">m</span><span style="color:#0033ff">a</span>
</div>
<br>
<div class="HGMNetwork_Rengarenk_font30">
<span style="color:#ff3200">H</span><span style="color:#ff6600">o</span><span style="color:#ff9900">s</span><span style="color:#ffcc00">t</span><span style="color:#ffff00">e</span><span style="color:#ccff00">d</span><span style="color:#99ff00">/</span><span style="color:#65ff00">S</span><span style="color:#32ff00">c</span><span style="color:#00ff00">r</span><span style="color:#00ff33">i</span><span style="color:#00ff65">p</span><span style="color:#00ff99">t</span><span style="color:#00ffcb">e</span><span style="color:#00ffff">d</span> <span style="color:#0099ff">B</span><span style="color:#0065ff">y</span><span style="color:#0033ff">:</span> <span style="color:#3300ff">H</span><span style="color:#6600ff">G</span><span style="color:#9800ff">M</span><span style="color:#cb00ff">N</span><span style="color:#ff00ff">e</span><span style="color:#ff00cb">t</span><span style="color:#ff0098">w</span><span style="color:#ff0066">o</span><span style="color:#ff0033">r</span><span style="color:#ff0000">k</span>
</div>
</div>
<br><br>
<button class="HGMNetwork_Buton" type="sumbit"><b>Sinusbot Olustur.</b></button>
<br><br>
</a>
<br><br>
<font size=4><b>Kullandiginiz Ip:</b> <font color="red"> <font size=2> <b>[<?php echo $ip; ?>]</b></font><font color=#FFFFFF><font size=2> &nbsp;<b>(Guvenlik Kosullari Nedeniyle<font color =red> Kayit Altindadir..!</font>)</font><br><br>
</body>
</html>